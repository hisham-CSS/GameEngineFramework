// Editor/src/EditorMain.cpp
#define MYCE_DEFINE_ENTRY
#include "../src/core/Main.h"