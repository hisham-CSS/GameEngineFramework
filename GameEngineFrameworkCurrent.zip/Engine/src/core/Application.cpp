#pragma once
#include "Application.h"

namespace MyCoreEngine
{
	Application::Application()
	{
	}

	Application::~Application()
	{
	}

	void Application::Run()
	{
	}
}