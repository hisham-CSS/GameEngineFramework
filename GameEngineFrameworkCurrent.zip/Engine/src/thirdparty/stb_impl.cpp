#pragma once
// Engine/src/thirdparty/stb_impl.cpp
#define STB_IMAGE_IMPLEMENTATION
// #define STB_IMAGE_WRITE_IMPLEMENTATION   // only if you actually use it
// #define STB_TRUETYPE_IMPLEMENTATION      // only if you actually use it
#include "stb_image.h"
